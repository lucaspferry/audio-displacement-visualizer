"""
    Author: Lucas Peter Ferry
    Python Version: 3.7.7
    OS: Windows 10
"""
import bpy
import os
import subprocess
from collections import namedtuple
import numpy as np
import tempfile
import wave
import math
import contextlib
import time

path = ''  # Path of the given audio file
selected_audio_path = ''  # Path selected via UI Panel in Blender

states = {
    'I': 'Idle',
    'R': 'Ready'
}

current_state = states['I']

# Create a tuple so we can assign a module as a dependency
Dependency = namedtuple("Dependency", ["module", "package", "name"])

# Set a dependency for Librosa library (Used in the audio extraction process)
dependencies = (Dependency(module="librosa", package=None, name=None),)

# Variable that checks if dependencies are installed
dependencies_installed = False

# Modes that can be used inside of the addon
modes = [('VORONOI', "Voronoi", ""),
         ('MUSGRAVE', "Musgrave", ""),
         ('STUCCI', "Stucci", ""),
         ('MAGIC', "Magic", ""),
         ('MARBLE', "Marble", "")]


########################################################
# Addon Initialization (Interface & Installer)
########################################################


bl_info = {
    "name": "Audio Displacement Visualizer",
    "description": """We can generate a displacement texture and\
    assign insensity values for it using amplitudes extracted\
    from a wav audio file.""",
    "author": "Lucas Ferry",
    "version": (1, 0),
    "blender": (2, 83, 0),
    "location": "PROPERTIES",
    "wiki_url": "https://drive.google.com/file/d/1niJHHtGnBnfN-mJo-Tn-DOS5CEwXl4gs/view?usp=sharing",
    "warning": """Requires installation of dependencies\
    (Install Below Before Execution)""",
    "support": "COMMUNITY",
    "category": "Object"
}


def import_module(module_name, global_name=None):

    """
    FUNCTIONALITY: Imports a module given its name and the name to rename it.

    PARAMETERS:
    :param: module_name: Name of the module we want to import
    :param: global_name: Name under which the module
    is imported, renaming it using the convention
    import libraryname as newlibraryname.

    RETURN:
    :return: No return paramaters.

    DESCRIPTION:
    We use importlib to import the module and save it
    in the globals variable for referencing.
    We use globals as if we typed import librosa
    for example directly. We use this
    to assure that we install the library
    firt and then import it.

    REFERENCES:

    [1] Robert Gützkow (2020, February 29).
    Bundling python library with addon. Stack Exchange.
    https://blender.stackexchange.com/questions/168448/
    bundling-python-library-with-addon

    """

    import importlib

    if global_name is None:
        global_name = module_name

    globals()[global_name] = importlib.import_module(module_name)


def install_pip():

    """
    FUNCTIONALITY: Installs pip if it isn't already installed.
    (Note that pip only comes installed by default in Blender for Windows).

    PARAMETERS:
    :param: No input parameters.

    RETURN:
    :return: No return paramaters.

    DESCRIPTION:
    We first use a subprocess to find out if pip is already
    installed on our PC. If not we use insurepip's bootstrap
    to install it. Note that we have to set PIP_REQ_TRACKER to
    None so we remove it from the enviroment variables after
    installation, because the install package folder gets removed
    after installation and shoudn't be referenced.

    REFERENCES:

    [1] Robert Gützkow (2020, February 29).
    Bundling python library with addon. Stack Exchange.
    https://blender.stackexchange.com/questions/168448/
    bundling-python-library-with-addon

    """

    try:
        # Check if pip is already installed
        subprocess.run(
            [bpy.app.binary_path_python, "-m", "pip", "--version"], check=True
            )
    except subprocess.CalledProcessError:
        import ensurepip

        ensurepip.bootstrap()
        os.environ.pop("PIP_REQ_TRACKER", None)


def install_and_import_module(
        module_name,
        package_name=None,
        global_name=None):

    """
    FUNCTIONALITY: Installs the indicated module through pip.

    PARAMETERS:
    :param: module name: Name of the module to import
    :param: package_name: Name of the package that needs
    to be installed (Optional). If None the package name
    will be the same as the module name
    global_name: Name under which the module is imported
    (Optional). I None the global name will be the
    same as the module name.

    RETURN:
    :return: No return paramaters.

    DESCRIPTION:
    We first check if a global name is used to import the module.
    If not, the global name will be the same as the module name.
    We then run a subprocess using pip to install the package
    we have input in the function.
    Once installed we import the module.

    REFERENCES:

    [1] Robert Gützkow (2020, February 29). Bundling python library with addon.
    Stack Exchange.
    https://blender.stackexchange.com/questions/168448/
    bundling-python-library-with-addon

    """

    if package_name is None:
        package_name = module_name

    if global_name is None:
        global_name = module_name

    # Try to install the package. This may fail with subprocess.
    # CalledProcessError
    subprocess.run(
        [bpy.app.binary_path_python,
            "-m", "pip",
            "install",
            package_name],
        check=True
        )

    # The installation succeeded, attempt to import the module again
    import_module(module_name, global_name)


class LayoutPanel(bpy.types.Panel):

    """
    FUNCTIONALITY: Panel that contains the functionality of the addon. It will
    be stored inside the object context in the properties editor.

    PARAMETERS:
    :param: No input parameters

    RETURN:
    :return: No return paramaters

    DESCRIPTION:
    We display all of the variables and checkboxes inside of the panel.
    We can select the type of displacement and the rotation and
    scale of the object reacting to the audio spikes.

    REFERENCES:

    [1] Blender (n.d). Add-on Tutorial. Blender.org.
    https://docs.blender.org/manual/en/latest/advanced/
    scripting/addon_tutorial.html

    [2] Blender (n.d). Operator(bpy_struct). Blender.org.
    https://docs.blender.org/api/current/bpy.types.Operator.html

    """

    bl_label = "Audio Displacement Visualizer"
    bl_idname = "SCENE_PT_layout"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "object"

    def draw(self, context):
        """Draws the panel with the correct operators"""
        layout = self.layout
        object = context.object

        layout.label(text="General Properties")
        row = layout.row()
        row.prop(object, "samples")
        row.prop(object, "cutoff")

        row = layout.row()
        row.prop(object, "displacement_mode")
        row.prop(object, "displacement_factor")

        row = layout.row()
        row.prop(object, "scaling")

        if object.scaling is True:
            row = layout.row()
            row.prop(object, "scale_x")
            row.prop(object, "scale_y")
            row.prop(object, "scale_z")

            row = layout.row()

            if object.scale_x is True:
                row.prop(object, "scale_factor_x")

            if object.scale_y is True:
                row.prop(object, "scale_factor_y")

            if object.scale_z is True:
                row.prop(object, "scale_factor_z")

        row = layout.row()
        row.prop(object, "rotating")

        if object.rotating is True:
            row = layout.row()
            row.prop(object, "rotation_x")
            row.prop(object, "rotation_y")
            row.prop(object, "rotation_z")

            row = layout.row()

            if object.rotation_x is True:
                row.prop(object, "rotation_factor_x")

            if object.rotation_y is True:
                row.prop(object, "rotation_factor_y")

            if object.rotation_z is True:
                row.prop(object, "rotation_factor_z")

        row = layout.row()
        row.prop(object, "bake")

        row = layout.row()
        row.label(text='Selected File: ' + selected_audio_path)

        row = layout.row()
        row.label(text='Status: ' + current_state)

        row = layout.row()
        row.operator(
            "object.open_filebrowser",
            text="Select File"
            )
        row.operator(
            "object.audioprocessingoperator",
            text="Run"
            )
        row = layout.row()
        row.label(text='Note: Only 16 or 8 bit WAV files supported')


class AudioProcessingOperator(bpy.types.Operator):

    """
    FUNCTIONALITY: This is the operator that the program
    executes when the user hits the button (Run).

    PARAMETERS:
    :param: No input parameters

    RETURN:
    :return: No return paramaters

    DESCRIPTION:
    This is the main operator for the addon,
    it checks if the object a object
    is selected, if not it disactivates itself.
    On invoke it opens a file dialog
    where we can select the wav. file we want to process.
    Once we have the desired filepath we can invoke
    run_addon using the context and the path obtained.
    We can find the addon under the object parameters tab.
    (Orange square in Blender)

    REFERENCES:

    [1] Yardie (2014, August).
    Prompt for filename in fileselect_add. Blenderartists.org.
    https://blenderartists.org/t/prompt-for-filename-in-fileselect-add/
    619936/2

    [2] hossan-tk9004 (2017).
    getFilePathFromFiledialog. Github Gist.
    https://gist.github.com/hossan-tk9004/2103a9ba5e6cf4d22d3132e399819787


    """

    bl_idname = "object.audioprocessingoperator"
    bl_description = ("""Applies the desired displacement
    texture to the object and inserts
    keyframes so the geometry reacts to the song amplitude""")
    bl_label = "Audio Processing Operator"

    @classmethod
    def poll(cls, context):
        """This is a method of the operator used to block
        the "Run" button in case that the
        boolean is false. The boolean is false if
        bpy.context.active_object is None.
        If one of these sentences are met,
        the user can't do the audio extraction."""
        boolean = False
        active = bpy.context.active_object
        global selected_audio_path
        global current_state
        if selected_audio_path is not None and selected_audio_path is not '':
            if active is not None:
                if dependencies_installed is True:
                    if active.type == 'MESH':
                        boolean = True
                        current_state = states['R']

        return boolean

    def execute(self, context):
        """ This method is used to execute the code. If there is no problem, it
        first calculates the interpolation and later inserts the frames."""
        global selected_audio_path
        global current_state
        if selected_audio_path is not None and selected_audio_path is not '':
            start_time = time.clock()
            run_addon(context, selected_audio_path)
            end_time = time.clock()
            print(
                ('File: {}, samples: {}  , time: {}'.format(
                    selected_audio_path,
                    context.object.samples,
                    end_time - start_time)))

        return {'FINISHED'}


class Install_dependencies(bpy.types.Operator):

    """
    FUNCTIONALITY: Operator that installs the
    desired dependencies and shows the file
    dialog for the installation below the main audio
    extraction addon.

    PARAMETERS:
    :param: No input parameters

    RETURN:
    :return: No return paramaters

    DESCRIPTION:
    This is the operator used to facilitate a button
    to execute the dependency installation if dependencies
    are already installed we disable this operator

    REFERENCES:

    [1] Robert Gützkow (2020, February 29).
    Bundling python library with addon. Stack Exchange.
    https://blender.stackexchange.com/questions/
    168448/bundling-python-library-with-addon

    """

    bl_idname = "object.install_dependencies"
    bl_label = "Install dependencies (213 MB)"
    bl_description = ("""Downloads and installs Librosa for this add-on. Internet connection
                    is required. Blender may have to be started with
                    elevated permissions in order to install the package""")
    bl_options = {"REGISTER", "INTERNAL"}

    @classmethod
    def poll(self, context):
        # Deactivate when dependencies have been installed
        return not dependencies_installed

    def execute(self, context):
        try:
            install_pip()
            for dependency in dependencies:
                install_and_import_module(module_name=dependency.module,
                                          package_name=dependency.package,
                                          global_name=dependency.name)
        except (subprocess.CalledProcessError, ImportError) as err:
            self.report({"ERROR"}, str(err))
            return {"CANCELLED"}

        global dependencies_installed
        dependencies_installed = True

        return {"FINISHED"}


class Preferences(bpy.types.AddonPreferences):

    """
    FUNCTIONALITY: Preferences tab that show the dialog option
    for installation

    PARAMETERS:
    :param: No input parameters

    RETURN:
    :return: No return paramaters

    DESCRIPTION:
    Below the addon there will appear a console icon where we can click
    and install dependencies

    REFERENCES:

    [1] Robert Gützkow (2020, February 29).
    Bundling python library with addon. Stack Exchange.
    https://blender.stackexchange.com/questions/
    168448/bundling-python-library-with-addon

    """

    bl_idname = __name__
    bl_label = "Installer"
    bl_description = ("""Dependencies: Librosa (213 MB)""")

    def draw(self, context):
        layout = self.layout
        layout.operator(
            Install_dependencies.bl_idname,
            icon="CONSOLE"
            )


class File_Browser(bpy.types.Operator):

    """
    FUNCTIONALITY: Operator to open up the pop-up
    for the file dialog window

    PARAMETERS:
    :param: No input parameters

    RETURN:
    :return: No return paramaters

    DESCRIPTION:
    Using this operator we will be able to select a file to
    process later.

    REFERENCES:

    [1] Blender (n.d). WindowManager(ID). Blender.org.
    https://docs.blender.org/api/blender_python_api_current/
    bpy.types.WindowManager.html
    """

    bl_idname = "object.open_filebrowser"
    bl_label = "Select Wav"
    bl_description = ("""Opens a file dialog to select
    the desired WAV file we want to process""")

    filepath = bpy.props.StringProperty(subtype="FILE_PATH")

    filename_ext = ".wav"
    filter_glob = bpy.props.StringProperty(
            default="*.wav",
            options={'HIDDEN'},
            )

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        global selected_audio_path
        if self.filepath:
            selected_audio_path = str(self.filepath)
        return {"FINISHED"}

    def invoke(self, context, event):
        global selected_audio_path
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


# Classes we want to register
classes = (
    Install_dependencies,
    Preferences,
    LayoutPanel,
    AudioProcessingOperator,
    File_Browser
    )


def register():

    """
    FUNCTIONALITY: We register all the panels and
    operators declared above and the variables
    associated to the main panel

    PARAMETERS:
    :param: No input parameters

    RETURN:
    :return: No return paramaters

    DESCRIPTION:
    We declare all the variables needes inside
    of the addon, we register the classes
    and we finally import any needed modules.

    REFERENCES:

    [1] Blender (n.d).
    The “register” class function (how to declare). Stack Exchange.
    https://blender.stackexchange.com/questions/
    28966/the-register-class-function-how-to-declare

    [2] Robert Gützkow (2020, February 29).
    Bundling python library with addon. Stack Exchange.
    https://blender.stackexchange.com/questions/168448/
    bundling-python-library-with-addon

    """

    global dependencies_installed
    dependencies_installed = False

    bpy.types.Object.samples = bpy.props.IntProperty(
        name="Samples",
        min=512,
        max=65536,
        default=1024,
        step=512
        )
    bpy.types.Object.cutoff = bpy.props.IntProperty(
        name="Cutoff",
        min=5,
        max=40000,
        default=50)
    bpy.types.Object.scaling = bpy.props.BoolProperty(
        name="Scale",
        default=False
        )
    bpy.types.Object.scale_x = bpy.props.BoolProperty(
        name="ScaleX",
        default=True
        )
    bpy.types.Object.scale_y = bpy.props.BoolProperty(
        name="ScaleY",
        default=True
        )
    bpy.types.Object.scale_z = bpy.props.BoolProperty(
        name="ScaleZ",
        default=True)
    bpy.types.Object.scale_factor_x = bpy.props.FloatProperty(
        name="X Scale Factor",
        min=1.0,
        max=20.0,
        default=5.0
        )
    bpy.types.Object.scale_factor_y = bpy.props.FloatProperty(
        name="Y Scale Factor",
        min=1.0, max=20.0,
        default=5.0
        )
    bpy.types.Object.scale_factor_z = bpy.props.FloatProperty(
        name="Z Scale Factor",
        min=1.0,
        max=20.0,
        default=5.0
        )
    bpy.types.Object.rotating = bpy.props.BoolProperty(
        name="Rotation",
        default=False
        )
    bpy.types.Object.rotation_x = bpy.props.BoolProperty(
        name="RotationX",
        default=True
        )
    bpy.types.Object.rotation_y = bpy.props.BoolProperty(
        name="RotationY",
        default=False
        )
    bpy.types.Object.rotation_z = bpy.props.BoolProperty(
        name="RotationZ",
        default=False
        )
    bpy.types.Object.rotation_factor_x = bpy.props.FloatProperty(
        name="X Rotation Factor",
        min=-20.0, max=20.0,
        default=1.0
        )
    bpy.types.Object.rotation_factor_y = bpy.props.FloatProperty(
        name="Y Rotation Factor",
        min=-20.0,
        max=20.0,
        default=1.0
        )
    bpy.types.Object.rotation_factor_z = bpy.props.FloatProperty(
        name="Z Rotation Factor",
        min=-20.0,
        max=20.0,
        default=1.0
        )
    bpy.types.Object.displacement_mode = bpy.props.EnumProperty(
        name="Mode",
        items=modes,
        default='VORONOI'
        )
    bpy.types.Object.displacement_factor = bpy.props.FloatProperty(
        name="Factor",
        min=-200.0,
        max=200.0,
        default=5.0
        )
    bpy.types.Object.bake = bpy.props.BoolProperty(
        name="Bake Keyframes To F-Curves",
        default=False
        )

    for cls in classes:
        bpy.utils.register_class(cls)

    try:
        for dependency in dependencies:
            import_module(
                module_name=dependency.module,
                global_name=dependency.name
                )
        dependencies_installed = True
    except ModuleNotFoundError:
        # Don't register other panels, operators etc.
        return


def unregister():

    """
    FUNCTIONALITY: This method is used to delete the panel,
    operators and the variables that are used in it.

    PARAMETERS:
    :param: No input parameters

    RETURN:
    :return: No return paramaters

    DESCRIPTION:
    We unregister every variable, panel or operator we have registered in the
    register function

    REFERENCES:

    [1] Blender (n.d). The “register” class function (how to declare).
    Stack Exchange.
    https://blender.stackexchange.com/questions/
    28966/the-register-class-function-how-to-declare

    [2] Robert Gützkow (2020, February 29).
    Bundling python library with addon. Stack Exchange.
    https://blender.stackexchange.com/questions/
    168448/bundling-python-library-with-addon

    """

    for cls in classes:
        bpy.utils.unregister_class(cls)

    del bpy.types.Object.samples
    del bpy.types.Object.cutoff
    del bpy.types.Object.scaling
    del bpy.types.Object.scale_x
    del bpy.types.Object.scale_y
    del bpy.types.Object.scale_z
    del bpy.types.Object.scale_factor_x
    del bpy.types.Object.scale_factor_y
    del bpy.types.Object.scale_factor_z
    del bpy.types.Object.rotating
    del bpy.types.Object.rotation_x
    del bpy.types.Object.rotation_y
    del bpy.types.Object.rotation_z
    del bpy.types.Object.rotation_factor_x
    del bpy.types.Object.rotation_factor_y
    del bpy.types.Object.rotation_factor_z
    del bpy.types.Object.displacement_mode
    del bpy.types.Object.displacement_factor
    del bpy.types.Object.bake


########################################################
# Blender Addon Execution Processor Module
########################################################


def write_song_temp_path(filename):

    """
    FUNCTIONALITY: Generates a temporary file with the path form the audio file
    so we can retrieve it later and add it to the video editor of Blender

    PARAMETRS:
    :param: filename: Filename/Path of the song we are processing

    RETURN:
    :return: temporary_file_name: Name of the temporary txt file just generated


    DESCRIPTION:
    We generate a temporary file with the .txt extension
    so we can write the path of the wav file we are currently processing

    REFERENCES:
    [1] Arjun Thakur (2018, December 7). Generate temporary files and
    directories using Python.
    tutorialspoint.
    https://www.tutorialspoint.com/
    generate-temporary-files-and-directories-using-python

    [2] Python File Write. (n.d).
    https://www.w3schools.com/python/
    python_file_write.asp

    [3] steveha (2012, February 14). How to open a file using the
    open with statement. Stack Overflow.
    https://stackoverflow.com/questions/9282967/
    how-to-open-a-file-using-the-open-with-statement

    """

    temporary_file_name = os.path.join(tempfile.gettempdir(), 'song_path.txt')

    with contextlib.closing(open(temporary_file_name, 'w')) as f:
        f.write(filename)

    return temporary_file_name


def generate_temp(time, output):

    """
    FUNCTIONALITY: Generates a temporary file with the time:amplitude values
    extracted from the wav file

    PARAMETRS:
    :param: time: Array of timestamps that will
    go along with the amplitude values
    output: Array of amplitudes that will go along with the timestamp values


    RETURN:
    :return: temporary_file_name: Name of the temporary txt file just generated


    DESCRIPTION:
    We generate a temporary file with the .txt extension
    so we can write the tuple time:amplitude for its future use

    REFERENCES:
    [1] Arjun Thakur (2018, December 7). Generate temporary files and
    directories using Python.
    tutorialspoint.
    https://www.tutorialspoint.com/
    generate-temporary-files-and-directories-using-python

    [2] halfdan, James MV (2017, March 24). Writing string to a file on a new
    line every time. Stack Overflow.
    https://stackoverflow.com/questions/2918362/
    writing-string-to-a-file-on-a-new-line-every-time

    [3] Python File Write. (n.d).
    Retrieved from https://www.w3schools.com/python/python_file_write.asp

    [4] steveha (2012, February 14). How to open a file using the
    open with statement. Stack Overflow.
    https://stackoverflow.com/questions/9282967/
    how-to-open-a-file-using-the-open-with-statement

    """

    temporary_file_name = os.path.join(tempfile.gettempdir(), 'time_amps.txt')

    with contextlib.closing(open(temporary_file_name, 'w')) as f:
        for i in range(0, len(time)):
            f.write(str(time[i]) + ":" + str(output[i]) + "\n")

    return temporary_file_name


def amplitude_envelope(signal, frame_size, hop_length):

    """
    FUNCTIONALITY: Function that extracts the maximum amplitude value
    for a certain frame size and a certain hop size from an audio
    signal

    PARAMETRS:
    :param: signal: Wav signal from which we are going to extract the data
    :param: frame_size: Range in which we are going to be
    :param: searching for the max amplitude


    RETURN:
    :return: We are returning the amplitude values we
    have obtained for that sampling rate


    DESCRIPTION:
    We create an array in which we store the amplitude
    values we have just sampled iterating
    from sample to sample depending on the
    hop range and returning the max value.

    REFERENCES:
    [1] musikalkemist (2020, July 30). AudioSignalProcessingForML. Github.
    https://github.com/musikalkemist/AudioSignalProcessingForML/blob/master/
    8-%20Implementing%20the%20amplitude%20envelope/
    Implementing%20the%20amplitude%20envelope.ipynb

    [2] Selcuk (2016, July 30). How do I change all negative
    numbers to zero in python? [duplicate]. Stack Overflow.
    https://stackoverflow.com/questions/36310897/
    how-do-i-change-all-negative-numbers-to-zero-in-python/36310913

    """
    result = np.array(
        [max(signal[i:i+frame_size])
            for i in range(0, len(signal), hop_length)])
    result = [0.0 if i < 0.0 else i for i in result]

    return [1.0 if i > 1.0 else i for i in result]


def load_extract(file_name):

    """
    FUNCTIONALITY: Loads and extracts the file data and the sampling rate
    from a wav file we provide.

    PARAMETRS:
    :param: file_name: File name of the wav from which we want to extract data

    RETURN:
    :return: It returns the amplitude array that we have sampled and the
    file data associated with that file


    DESCRIPTION:
    We first load the file with the file name and we obtain the file
    data and the sampling rate of the file. We then using those
    parameters together with the frame size and the hop
    size call the amplitude evelope extractor and we also
    return the file data

    REFERENCES:
    [1] musikalkemist (2020, July 30). AudioSignalProcessingForML. Github.
    https://github.com/musikalkemist/AudioSignalProcessingForML/
    blob/master/8-%20Implementing%20the%20amplitude%20envelope/
    Implementing%20the%20amplitude%20envelope.ipynb

    """

    file_data, sr = librosa.load(file_name)
    return amplitude_envelope(file_data, FRAME_SIZE, HOP_SIZE)


def frames_and_time(output):

    """
    FUNCTIONALITY: Function that gives uss the frames and time data for a given
    amplitude array

    PARAMETRS:
    :param: output: Array that contains the amplitudes extracted
    from the wav file

    RETURN:
    :return: frames: array of frames that been processed
    :return: t: array of seconds in which the amplitudes have been sampled


    DESCRIPTION:
    This function given a number of frames returns the timestamps so we can
    later create an array of amplitudes in function of time.

    REFERENCES:
    [1] musikalkemist (2020, July 30). AudioSignalProcessingForML. Github.
    https://github.com/musikalkemist/AudioSignalProcessingForML/blob/
    master/8-%20Implementing%20the%20amplitude%20envelope/
    Implementing%20the%20amplitude%20envelope.ipynb

    """

    frames = range(len(output))
    t = librosa.frames_to_time(frames, hop_length=HOP_SIZE)

    return t


def running_mean(channel, winSize):

    """
    FUNCTIONALITY: Function that calculates the running mean of a
    1D array in a specific window

    PARAMETRS:
    :param: channel: Array for the first channel of the wav file
    :param: winSize: The size of the window in which we want to
    evaluate the running mean. In this case it will
    be the range that won't be low passed from
    the filtering process

    RETURN:
    :return: Array of the running mean value in the given window
    size

    DESCRIPTION:
    Cumsum is used to calculate the cumulative sum over a
    given axis of an array,
    usefull for future audio processing as filtering

    REFERENCES:
    [1] Alleo, Trevor Boyd Smith (2020, Februrary 21).
    Moving average or running mean. Stack Overflow.
    https://stackoverflow.com/questions/13728392/moving-average-or-running-mean

    [2] piercus (2015). wav_lowpass_example. GitHub Gist.
    https://gist.github.com/piercus/b005ed5fbc70761bde96

    """

    # Inserts a 0 before the input array for a more precise acumulative sum
    cumsum = np.cumsum(np.insert(channel, 0, 0))

    # We get an array covering everything except the window size and we
    # average it out following the IIR filter principle
    return (cumsum[winSize:] - cumsum[:-winSize]) / float(winSize)


def interpret_wav(
        raw_bytes, n_frames, n_channels, sample_width, interleaved=True):

    """
    FUNCTIONALITY: Interprets the wave file for future filtering

    PARAMETRS:
    :param: raw_bytes: Raw bytes of the audio file calculated with the
    formula numberOfFrames*numberOfChannels
    :param: n_frames: Number of frames cointained in the audio file
    :param: n_channels: number of channels of the audio file,
    generally two if it's a stereo track
    :param: sample_width: Amplitude width of the sample,
    it gives us information
    about the coding of the file (8 bit int or 16 bit int)
    :param: interveraled: a bool value telling the function if
    L and R channels are in a single file or in separate files

    RETURN:
    :return: channels: Channels coded in raw byte data for filtering

    DESCRIPTION:
    The function first checks what kind of coding the
    sample has and generates and array with byte
    data. Once it has this information it checks
     if the code is intervealed or not, and depending
    on which option it selected it will use a
    different kind od processing as intervealed has both right and
    left channel inside a single file.

    REFERENCES:
    [1] rudolfbyker (2015, July 25). Interpreting WAV Data. Stack Overflow.
    https://stackoverflow.com/questions/2226853/
    interpreting-wav-data/2227174#2227174

    [2] piercus (2015). wav_lowpass_example. GitHub Gist.
    https://gist.github.com/piercus/b005ed5fbc70761bde96

    """

    if sample_width == 1:
        dtype = np.uint8  # unsigned char
    elif sample_width == 2:
        dtype = np.int16  # signed 2-byte short
    else:
        raise ValueError("Only supports 8 and 16 bit audio formats.")

    # constructs and array of the raw byte data
    channels = np.frombuffer(raw_bytes, dtype=dtype)

    # intervealed means that there will be only one
    # file for both Left and Right channels
    if interleaved:
        # channels are interleaved, i.e. sample N of channel
        # M follows sample N of channel M-1 in raw data
        channels.shape = (n_frames, n_channels)
        channels = channels.T
    else:
        # channels are not interleaved. All samples from channel
        # M occur before all samples from channel M-1
        channels.shape = (n_channels, n_frames)

    return channels


def filtering(fname):

    """
    FUNCTIONALITY: Function that manages and filters the audio for
    future processing

    PARAMETRS:
    :param: fname: File name of the wav file we want to filter

    RETURN:
    :return: outname: Name of the filtered file

    DESCRIPTION:
    The function first of all extracts all of the data needed, like samplerate
    ampwidth, number of channels and number of frames.
    It then proceeds to extract
    the raw audio data and it extracts the channel data from the track.
    Once given a cutoff frequency we can now calcualte the
    window size that will affect the resulting
    audio file. Filtering is applied with the running mean function.
    Finally a temporary file is created and the
    byte data is written to
    the new audio file for future processing.

    REFERENCES:
    [1] Massimo (2014, February 25).
    What is the cut-off frequency of a moving average filter?. Stack Exchange.
    https://dsp.stackexchange.com/questions/9966/
    what-is-the-cut-off-frequency-of-a-moving-average-filter

    [2] piercus (2015). wav_lowpass_example. GitHub Gist.
    https://gist.github.com/piercus/b005ed5fbc70761bde96

    """

    try:
        with contextlib.closing(wave.open(fname, 'rb')) as spf:
            sampleRate = spf.getframerate()
            ampWidth = spf.getsampwidth()
            nChannels = spf.getnchannels()
            nFrames = spf.getnframes()

            # Extract Raw Audio from multi-channel Wav File
            signal = spf.readframes(nFrames*nChannels)
            spf.close()
            channels = interpret_wav(
                signal,
                nFrames,
                nChannels,
                ampWidth,
                True)

            N = getWindowSize(sampleRate)

            # Use moving average (only on first channel)
            filtered = running_mean(channels[0], N).astype(channels.dtype)
            outname = os.path.join(tempfile.gettempdir(), 'filtered.wav')

            with wave.open(outname, 'w') as wav_file:
                wav_file.setparams((
                    1,
                    ampWidth,
                    sampleRate,
                    nFrames,
                    spf.getcomptype(),
                    spf.getcompname()))

                wav_file.writeframes(filtered.tobytes('C'))
    except wave.Error:
        raise ValueError("Only supports 8 and 16 bit audio formats.")

    return outname


def getWindowSize(sampleRate):

    """
    FUNCTIONALITY: Get the windows size given a cutoff
    frequency and a samplerate

    PARAMETRS:
    :param: sampelerate: Sample rate of the wav file

    RETURN:
    :return: outname: It gives us the window size in which
    we will apply the filtering process.
    It's also denoted with the character N.

    DESCRIPTION:
    We first calculate the frequency ration needed to calculate the window
    size. Generally we can calculate the frequency ratio by inputting
    the window size, but we inverse the equation to obtain
    the window size. The formula is the one stated below.

    REFERENCES:
    [1] Massimo (2014, February 25). What is the cut-off
    frequency of a moving average filter?. Stack Exchange.
    https://dsp.stackexchange.com/questions/9966/
    what-is-the-cut-off-frequency-of-a-moving-average-filter

    [2] piercus (2015). wav_lowpass_example. GitHub Gist.
    https://gist.github.com/piercus/b005ed5fbc70761bde96

    """

    freqRatio = (cutOffFrequency/sampleRate)
    return int(math.sqrt(0.196202 + freqRatio**2)/freqRatio)


def delete(file_name):

    """
    FUNCTIONALITY: Deletes a file given a path

    PARAMETRS:
    :param: file_name: Name of the file that we want to delete

    RETURN:
    No return variables

    DESCRIPTION: If the given file name exists
    the operating system will delete it


    REFERENCES:
    [1] Python Delete File. (n.d).
    Retrieved from https://www.w3schools.com/python/python_file_remove.asp

    """

    if os.path.exists(file_name):
        os.remove(file_name)
    else:
        print("The file does not exist")


def audio_extraction():

    """
    FUNCTIONALITY: Does all the function calls to
    functions that do the audio extraction

    DESCRIPTION: Calls the function to open teh dialog box
    it applies filtering to that track, it then extracts
    the amplitudes from the trakc and genertates a
    temporary file with that output. Finally it deletes
    the filtered audio sequence as it was temporary

    """

    origin_file_name = path
    filtered_wav_file_name = filtering(origin_file_name)
    output = load_extract(filtered_wav_file_name)
    time = frames_and_time(output)
    generate_temp(time, output)
    delete(filtered_wav_file_name)


def run_audio_processor(samples, cutoff, directory):

    """
    FUNCTIONALITY: We capture the variables sent from
    the Blender add-on script and we then call the
    audio extraction function.

    PARAMETRS:
    :param: samples: The frame size input
    :param: cutoff: The cut off frequency for the filter
    :param: directory: Directory of the audio file

    RETURN:
    No return parmeters

    """

    global FRAME_SIZE
    global cutOffFrequency
    global HOP_SIZE
    global path

    FRAME_SIZE = samples
    cutOffFrequency = cutoff
    path = directory
    HOP_SIZE = int(FRAME_SIZE/2)

    audio_extraction()


########################################################
# Audio Extraction Module
########################################################


def read_temp(temp_file_name):

    """
    FUNCTIONALITY: Reads a temporary file generated previously
    with the time:amplitude values extracted from the wav file

    PARAMETRS:
    :param: temp_file_name: The name of the temporary file we are looking for


    RETURN:
    :return: arr: Array of type time:amplitude both in float value


    DESCRIPTION:
    We open the temporary file to read it and extract the tuple time:amplitude
    for future processing

    REFERENCES:
    [1] Adam McQuistan (n.d). Read a File Line-by-Line in Python.
    Stack Abuse. https://stackabuse.com/
    read-a-file-line-by-line-in-python/

    [2] Cameron (2011, March 22). How to convert a string with
    comma-delimited items to a list in Python?.
    https://stackoverflow.com/questions/5387208/
    how-to-convert-a-string-with-comma-delimited-items-to-a-list-in-python

    [3] steveha (2012, February 14). How to open a file
    using the open with statement. Stack Overflow.
    https://stackoverflow.com/questions/9282967/
    how-to-open-a-file-using-the-open-with-statement

    """

    arr = []
    with open(temp_file_name, 'r') as f:
        for count, line in enumerate(f):
            splitted = line.split(":")
            arr.append([float(splitted[0]), float(splitted[1])])

    return arr


def run_audio_extraction(context, directory):

    """
    FUNCTIONALITY: Calls the extraction module over the operating
    system using the arguments, frame size and cut off frequency
    needed for the amplitude extraction

    PARAMETRS:
    No input parameters

    RETURN:
    No return variables

    DESCRIPTION: We call the script audioextraction.py via
    the operating system


    REFERENCES:
    [1] Greg Hewgill (2010, September 23). Run a Python script
    from another Python script, passing in arguments.
    https://stackoverflow.com/questions/3781851/
    run-a-python-script-from-another-python-script-passing-in-arguments

    """
    run_audio_processor(
        int(context.object.samples),
        int(context.object.cutoff),
        directory
        )


def insert_frames(read_array, context):

    """
    FUNCTIONALITY: This function is used to create the desired
    audio visualization effect using voronoi textures and
    scaling de object accordingly.

    PARAMETRS:
    :param: read_array: The array containing the tuple, time:amplitude

    RETURN:
    No return variables


    DESCRIPTION: We first create a new texture with the type Voronoi and
    we configure it with out desired values. We then check if the current
    selected object has a displacement modifier so we can attach the
    voronoi texture to it. If it doesn't exist a new modifier is created
    and linked to the currently selected object.
    We then use a foor loop to first, extract the amplitude value from the
    read array and the frame we are in (in seconds).
    We then insert the amplitude by the max value from the voronoi texture
    into the noise intensity value of the texture as keyframes. Calcuting
    the correct frame by multiplying the time by the frames per second.
    We repeat the process but for scaling the object.
    Finally, we assign the voronoi texture with the keyframes to the
    displacemente modifier, and we assign it a strength and a vertex group


    REFERENCES:
    [1] lemon (2019, September 17). How to create a
    generic texture using python?.
    https://blender.stackexchange.com/questions/152971/
    how-to-create-a-generic-texture-using-python

    [2] Blender (n.d). VoronoiTexture(Texture)
    https://docs.blender.org/api/current/bpy.types.VoronoiTexture.html

    [3] zeffii (2015, July 27). How to find the
    data_path for scripted keyframes.
    https://blender.stackexchange.com/questions/
    34590/how-to-find-the-data-path-for-scripted-keyframes

    [4] Blender (n.d). Context Access (bpy.context)
    https://docs.blender.org/api/master/
    bpy.context.html#bpy.context.selected_objects

    [5] Chebhou (2015, February 25). How to bake F-Curve using python?
    https://blender.stackexchange.com/questions/
    26283/how-to-bake-f-curve-using-python


    """

    correct = ['modifiers["Displace"].strength', 'scale', 'rotation_euler']

    fps = context.scene.render.fps
    obj = context.object

    check = True

    if obj.animation_data:
        if obj.animation_data.action:
            curve = obj.animation_data.action.fcurves.find(
                correct[0],
                index=0
                )
            if curve and not curve.is_empty and len(
                    curve.keyframe_points) == 0:
                check = False

            if obj.scaling:
                curve = obj.animation_data.action.fcurves.find(
                    correct[1],
                    index=0
                    )
                if curve and not curve.is_empty and len(
                        curve.keyframe_points) == 0:
                    check = False

            if obj.rotating:
                curve = obj.animation_data.action.fcurves.find(
                    correct[2],
                    index=0
                    )
                if curve and not curve.is_empty and len(
                        curve.keyframe_points) == 0:
                    check = False

    if check:

        if obj.displacement_mode == 'VORONOI':
            voronoi_tex = bpy.data.textures.new(
                "displace_voronoi",
                'VORONOI'
                )
            voronoi_tex.noise_scale = .64
            voronoi_tex.nabla = .05
            voronoi_tex.noise_intensity = 7.9
            voronoi_tex.weight_1 = -.7
            voronoi_tex.weight_2 = .599
            voronoi_tex.weight_3 = .224
            voronoi_tex.weight_4 = -.00047

        elif obj.displacement_mode == 'MUSGRAVE':
            musgrave_tex = bpy.data.textures.new(
                "displace_musgrave",
                'MUSGRAVE'
                )
            musgrave_tex.noise_scale = .17
            musgrave_tex.nabla = .10
            musgrave_tex.dimension_max = 2
            musgrave_tex.lacunarity = 0.01
            musgrave_tex.octaves = 1.03
            musgrave_tex.noise_intensity = 0.04

        elif obj.displacement_mode == 'STUCCI':
            stucci_tex = bpy.data.textures.new(
                "displace_stucci",
                'STUCCI'
                )
            stucci_tex.noise_type = "HARD_NOISE"
            stucci_tex.noise_basis = "CELL_NOISE"
            stucci_tex.noise_scale = 1.16
            stucci_tex.turbulence = 0.0

        elif obj.displacement_mode == 'MAGIC':
            magic_tex = bpy.data.textures.new(
                "displace_magic",
                'MAGIC'
                )
            magic_tex.noise_depth = 4
            magic_tex.turbulence = 2.3

        elif obj.displacement_mode == 'MARBLE':
            marble_tex = bpy.data.textures.new(
                "displace_marble",
                'MARBLE'
                )
            marble_tex.marble_type = "SHARPER"
            marble_tex.noise_scale = 2
            marble_tex.noise_depth = 0
            marble_tex.turbulence = 23.80
            marble_tex.nabla = 0.05

        disp_mod = None
        for modifier in obj.modifiers:
            if modifier.type == 'DISPLACE':
                disp_mod = modifier

        if not disp_mod:
            disp_mod = obj.modifiers.new(
                name='Displace',
                type='DISPLACE'
                )

        for i in range(0, len(read_array)):
            value = read_array[i][1]
            frame = read_array[i][0]

            disp_mod.strength = obj.displacement_factor * value
            disp_mod.keyframe_insert(
                data_path='strength',
                frame=frame*fps
                )

            if obj.scaling:
                if obj.scale_x:
                    obj.scale.x = obj.scale_factor_x * value + 2

                if obj.scale_y:
                    obj.scale.y = obj.scale_factor_y * value + 2

                if obj.scale_z:
                    obj.scale.z = obj.scale_factor_z * value + 2

                if obj.scale_x or obj.scale_y or obj.scale_z:
                    obj.keyframe_insert(data_path='scale', frame=frame*fps)

            if obj.rotating:
                if obj.rotation_x:
                    obj.rotation_euler.x += obj.rotation_factor_x * value

                if obj.rotation_y:
                    obj.rotation_euler.y += obj.rotation_factor_y * value

                if obj.rotation_z:
                    obj.rotation_euler.z += obj.rotation_factor_z * value

                if obj.rotation_x or obj.rotation_y or obj.scale_z:
                    obj.keyframe_insert(
                        data_path='rotation_euler',
                        frame=frame*fps)

        if obj.displacement_mode == 'VORONOI':
            disp_mod.texture = voronoi_tex
        elif obj.displacement_mode == 'MUSGRAVE':
            disp_mod.texture = musgrave_tex
        elif obj.displacement_mode == 'STUCCI':
            disp_mod.texture = stucci_tex
        elif obj.displacement_mode == 'MAGIC':
            disp_mod.texture = magic_tex
        elif obj.displacement_mode == 'MARBLE':
            disp_mod.texture = marble_tex

        disp_mod.vertex_group = "Group"

        if obj.bake:
            area = bpy.context.area
            if area:
                old_type = area.type
            if obj.animation_data:
                if obj.animation_data.action:
                    if obj.animation_data.action.fcurves:
                        curves = obj.animation_data.action.fcurves

                        for curve in curves:
                            if not curve.is_empty and str(
                                    curve.data_path) in correct:
                                curve.select = True
                                area.type = 'GRAPH_EDITOR'
                                bpy.ops.graph.bake()
                                if old_type:
                                    area.type = old_type


def add_song(file_path_name):

    """
    FUNCTIONALITY: Adds the previous processed audio wav to
    the video editor inside Blender

    PARAMETRS:
    :param: file_path_name: The path of the audio file we want to add.

    RETURN:
    No return variables

    DESCRIPTION:
    We first of all get the context of the scene
    so we can check if there is a sequence
    already created. If it doesn't exist we create it.
    After that we insert the
    audio file in the channel 3 at frame 1.

    REFERENCES:

    [1] batFINGER (2016, September 27). How to add sound
    to sequencer using Python.
    https://blender.stackexchange.com/questions/63834/
    how-to-add-sound-to-sequencer-using-python


    """

    scene = bpy.context.scene

    if not scene.sequence_editor:
        scene.sequence_editor_create()

    name = os.path.basename(os.path.normpath(file_path_name))

    check = False
    full_channels = []
    for sequence in scene.sequence_editor.sequences_all:
        if sequence.name == name:
            check = True
            break
        full_channels.append(sequence.channel)   

    if not check:
        current_channel = 1
        while current_channel in full_channels:
            current_channel += 1

        scene.sequence_editor.sequences.new_sound(
            name,
            file_path_name,
            current_channel,
            0)


def run_addon(context, directory):

    """
    FUNCTIONALITY: This function is the one in charge to call
    every single function and module for the audio
    extraction process.

    PARAMETRS:
    No input parameters

    RETURN:
    No return parmeters

    DESCRIPTION:
    We first run the audio extraction module, we read
    the temporary time:amplitude file generated in the
    audio extraction process. We then insert the keyframes
    inside of our scene. We then read the file containing
    the path of our song and we add it to the video
    editor of Blender. Finally we delete all temporary
    files created in the process.

    """
    run_audio_extraction(context, directory)
    temp_file_name = os.path.join(tempfile.gettempdir(), 'time_amps.txt')
    read_array = read_temp(temp_file_name)
    insert_frames(read_array, context)
    add_song(directory)
    delete(temp_file_name)
